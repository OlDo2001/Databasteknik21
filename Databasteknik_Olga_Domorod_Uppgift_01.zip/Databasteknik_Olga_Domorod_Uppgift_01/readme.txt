                                  Rapport
Datum: 2021-02-09
Kurs: Databasteknik
Klass: Kvalit20
Student: Olga_Domorod



Reflektioner:

Jag kan konstatera att Uppgift 1 var lagom svårt och intressant.

En del av uppgiften liknade exemplet från föreläsningen men det var intressant att gå igenom
varje steg i uppgiften för att förstå hur det hela fungerar. Under processen såg jag inspelningen igen. 
Det var viktigt för mig att se koden och lysna förklaringarna för att förstå vad jag gör.

Några punkter var utmanande för mig. Till exempel använde jag filter för första gången för att rensa
och validera data. Jag försökte olika alternativ innan jag hittade ett sätt för åtgärden att börja funka
korrekt. Det var mycket testning.

Det var roligt också att prova olika bootstrap templates och "leka" lite med utseendet. 

Det var nytt för mig att tänka över Admin sidan. Jag känner att för varje uppgift jag förstår mer 
och lär mig mer.

