<hr>
 <footer class="text-center text-muted">
 Copyright &copy; Olga Domorod <?php echo date('Y'); ?>
 </footer>
 
    </body>
</html>