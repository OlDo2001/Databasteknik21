<!doctype html>
<html lang="sv">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../bootstrap.css">
    <title>Admin sida</title>
</head>
<body class="container">
    <h1 class="text-center"> 
    <a href="index.php">Admin sida</a>
    </h1>


