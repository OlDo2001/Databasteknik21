<!doctype html>
<html lang="sv">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap.css">
    <style> 
        textarea {
            width: 100%;
            height:200px;
            padding: 12px 20px;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
            background-color: #f8f8f8;
            font-size: 16px;
            resize: none;
}
    </style>
    <title>Kontaktformulär</title>
  </head>
    <body class="container">
    <h1 class="text-center"> 
    <a href="index.php">Kontaktformulär</a>
    </h1>
